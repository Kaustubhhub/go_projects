<!--
NOTE: In this document and others in this directory, the convention is to
set fixed-width phrases with non-fixed-width spaces, as in
`hello` `world`.
-->

<style>
  main ul li { margin: 0.5em 0; }
</style>

## DRAFT RELEASE NOTES — Introduction to Go 1.23 {#introduction}

**Go 1.23 is not yet released. These are work-in-progress release notes.
Go 1.23 is expected to be released in August 2024.**
